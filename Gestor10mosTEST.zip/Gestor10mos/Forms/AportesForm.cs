﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;
using Gestor10mos.Entities;

namespace Gestor10mos.Forms
{
    public partial class AportesForm : Form
    {
        private List<Aporte> aportes = new List<Aporte>();
        private List<string> listaMiembros;

        
        public AportesForm(List<string> miembros)
        {
            InitializeComponent();
            listaMiembros = miembros;
            CargarTablaAportes();
        }

        private void CargarTablaAportes()
        {
            tablaAportes.DataSource = null;
            tablaAportes.DataSource = aportes;
        }

        private void btnAgregarAporte_Click(object sender, EventArgs e)
        {
            using (var detalle = new DetalleAporteForm())
            {
                detalle.CargarMiembros(listaMiembros);
                if (detalle.ShowDialog() == DialogResult.OK)
                {
                    var nuevo = new Aporte
                    {
                        Fecha = detalle.FechaAporte,
                        Monto = detalle.MontoAporte,
                        Descripcion = detalle.DescripcionAporte,
                        Miembro = detalle.MiembroAporte
                    };
                    aportes.Add(nuevo);
                    CargarTablaAportes();
                }
            }
        }

        private void btnEditarAporte_Click(object sender, EventArgs e)
        {
            if (tablaAportes.CurrentRow == null) return;

            var seleccionado = (Aporte)tablaAportes.CurrentRow.DataBoundItem;
            using (var detalle = new DetalleAporteForm())
            {
                detalle.CargarMiembros(listaMiembros);
                detalle.FechaAporte = seleccionado.Fecha;
                detalle.MontoAporte = seleccionado.Monto;
                detalle.DescripcionAporte = seleccionado.Descripcion;
                detalle.MiembroAporte = seleccionado.Miembro;

                if (detalle.ShowDialog() == DialogResult.OK)
                {
                    seleccionado.Fecha = detalle.FechaAporte;
                    seleccionado.Monto = detalle.MontoAporte;
                    seleccionado.Descripcion = detalle.DescripcionAporte;
                    seleccionado.Miembro = detalle.MiembroAporte;
                    CargarTablaAportes();
                }
            }
        }

        private void btnEliminarAporte_Click(object sender, EventArgs e)
        {
            if (tablaAportes.CurrentRow == null) return;

            var seleccionado = (Aporte)tablaAportes.CurrentRow.DataBoundItem;
            var resp = MessageBox.Show(
                "¿Eliminar este aporte?",
                "Confirmar",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Warning
            );
            if (resp == DialogResult.Yes)
            {
                aportes.Remove(seleccionado);
                CargarTablaAportes();
            }
        }
    }
}