﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;
using Gestor10mos.Entities;

namespace Gestor10mos.Forms
{
    public partial class MiembrosForm : Form
    {
        private List<Miembro> miembros = new List<Miembro>();

        public MiembrosForm()
        {
            InitializeComponent();
            CargarTablaMiembros();
        }

        private void CargarTablaMiembros()
        {
            tablaMiembros.DataSource = null;
            tablaMiembros.DataSource = miembros;
        }

        private void btnAgregarMiembro_Click(object sender, EventArgs e)
        {
            using (var detalle = new DetalleMiembroForm())
            {
                if (detalle.ShowDialog() == DialogResult.OK)
                {
                    miembros.Add(new Miembro
                    {
                        Nombre = detalle.NombreMiembro,
                        Apellido = detalle.ApellidoMiembro,
                        FechaIngreso = detalle.FechaIngresoMiembro,
                        Telefono = detalle.TelefonoMiembro,
                        Email = detalle.EmailMiembro
                    });
                    CargarTablaMiembros();
                }
            }
        }

        private void btnEditarMiembro_Click(object sender, EventArgs e)
        {
            if (tablaMiembros.CurrentRow == null) return;
            var sel = (Miembro)tablaMiembros.CurrentRow.DataBoundItem;
            using (var detalle = new DetalleMiembroForm())
            {
                detalle.NombreMiembro = sel.Nombre;
                detalle.ApellidoMiembro = sel.Apellido;
                detalle.FechaIngresoMiembro = sel.FechaIngreso;
                detalle.TelefonoMiembro = sel.Telefono;
                detalle.EmailMiembro = sel.Email;

                if (detalle.ShowDialog() == DialogResult.OK)
                {
                    sel.Nombre = detalle.NombreMiembro;
                    sel.Apellido = detalle.ApellidoMiembro;
                    sel.FechaIngreso = detalle.FechaIngresoMiembro;
                    sel.Telefono = detalle.TelefonoMiembro;
                    sel.Email = detalle.EmailMiembro;
                    CargarTablaMiembros();
                }
            }
        }

        private void btnEliminarMiembro_Click(object sender, EventArgs e)
        {
            if (tablaMiembros.CurrentRow == null) return;
            var sel = (Miembro)tablaMiembros.CurrentRow.DataBoundItem;
            var r = MessageBox.Show("¿Eliminar al miembro?", "Confirmar", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (r == DialogResult.Yes)
            {
                miembros.Remove(sel);
                CargarTablaMiembros();
            }
        }
    }
}