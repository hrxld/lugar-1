﻿namespace Gestor10mos.Forms
{
    partial class AportesForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tablaAportes = new System.Windows.Forms.DataGridView();
            this.btnAgregarAporte = new System.Windows.Forms.Button();
            this.btnEditarAporte = new System.Windows.Forms.Button();
            this.btnEliminarAporte = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.tablaAportes)).BeginInit();
            this.SuspendLayout();
            // 
            // tablaAportes
            // 
            this.tablaAportes.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.tablaAportes.Location = new System.Drawing.Point(20, 20);
            this.tablaAportes.Name = "tablaAportes";
            this.tablaAportes.RowHeadersWidth = 51;
            this.tablaAportes.RowTemplate.Height = 24;
            this.tablaAportes.Size = new System.Drawing.Size(760, 350);
            this.tablaAportes.TabIndex = 0;
            // 
            // btnAgregarAporte
            // 
            this.btnAgregarAporte.Location = new System.Drawing.Point(72, 395);
            this.btnAgregarAporte.Name = "btnAgregarAporte";
            this.btnAgregarAporte.Size = new System.Drawing.Size(75, 23);
            this.btnAgregarAporte.TabIndex = 1;
            this.btnAgregarAporte.Text = "Agregar";
            this.btnAgregarAporte.UseVisualStyleBackColor = true;
            // 
            // btnEditarAporte
            // 
            this.btnEditarAporte.Location = new System.Drawing.Point(257, 394);
            this.btnEditarAporte.Name = "btnEditarAporte";
            this.btnEditarAporte.Size = new System.Drawing.Size(75, 23);
            this.btnEditarAporte.TabIndex = 2;
            this.btnEditarAporte.Text = "Editar";
            this.btnEditarAporte.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnEditarAporte.UseVisualStyleBackColor = true;
            // 
            // btnEliminarAporte
            // 
            this.btnEliminarAporte.Location = new System.Drawing.Point(513, 394);
            this.btnEliminarAporte.Name = "btnEliminarAporte";
            this.btnEliminarAporte.Size = new System.Drawing.Size(75, 23);
            this.btnEliminarAporte.TabIndex = 3;
            this.btnEliminarAporte.Text = "Eliminar";
            this.btnEliminarAporte.UseVisualStyleBackColor = true;
            // 
            // AportesForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnEliminarAporte);
            this.Controls.Add(this.btnEditarAporte);
            this.Controls.Add(this.btnAgregarAporte);
            this.Controls.Add(this.tablaAportes);
            this.Name = "AportesForm";
            this.Text = "AportesForm";
            ((System.ComponentModel.ISupportInitialize)(this.tablaAportes)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGridView tablaAportes;
        private System.Windows.Forms.Button btnAgregarAporte;
        private System.Windows.Forms.Button btnEditarAporte;
        private System.Windows.Forms.Button btnEliminarAporte;
    }
}