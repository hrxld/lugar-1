﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;

namespace Gestor10mos.Forms
{
    public partial class DetalleAporteForm : Form
    {
        public DetalleAporteForm()
        {
            InitializeComponent();
        }

        // Propiedades para leer/escribir controles
        public DateTime FechaAporte
        {
            get => dtpFechaAporte.Value;
            set => dtpFechaAporte.Value = value;
        }

        public decimal MontoAporte
        {
            get => decimal.TryParse(txtMontoAporte.Text, out var m) ? m : 0;
            set => txtMontoAporte.Text = value.ToString("F2");
        }

        public string DescripcionAporte
        {
            get => txtDescripcionAporte.Text;
            set => txtDescripcionAporte.Text = value;
        }

        public string MiembroAporte
        {
            get => cmbMiembroAporte.Text;
            set => cmbMiembroAporte.Text = value;
        }

        // Método para llenar el ComboBox
        public void CargarMiembros(List<string> miembros)
        {
            cmbMiembroAporte.DataSource = null;
            cmbMiembroAporte.DataSource = miembros;
        }
    }
}