﻿using System;
using System.Windows.Forms;

namespace Gestor10mos.Forms
{
    public partial class CuentasForm : Form
    {
        public CuentasForm()
        {
            InitializeComponent();
        }
    }
}
