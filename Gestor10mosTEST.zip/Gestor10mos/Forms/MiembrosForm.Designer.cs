﻿namespace Gestor10mos.Forms
{
    partial class MiembrosForm
    {
        private System.ComponentModel.IContainer components = null;
        private System.Windows.Forms.DataGridView tablaMiembros;
        private System.Windows.Forms.Button btnAgregarMiembro;
        private System.Windows.Forms.Button btnEditarMiembro;
        private System.Windows.Forms.Button btnEliminarMiembro;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.tablaMiembros = new System.Windows.Forms.DataGridView();
            this.btnAgregarMiembro = new System.Windows.Forms.Button();
            this.btnEditarMiembro = new System.Windows.Forms.Button();
            this.btnEliminarMiembro = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.tablaMiembros)).BeginInit();
            this.SuspendLayout();
             
            // tablaMiembros
             
            this.tablaMiembros.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.tablaMiembros.Location = new System.Drawing.Point(12, 12);
            this.tablaMiembros.Name = "tablaMiembros";
            this.tablaMiembros.Size = new System.Drawing.Size(760, 350);
            this.tablaMiembros.TabIndex = 0;
             
            // btnAgregarMiembro
             
            this.btnAgregarMiembro.Location = new System.Drawing.Point(12, 380);
            this.btnAgregarMiembro.Name = "btnAgregarMiembro";
            this.btnAgregarMiembro.Size = new System.Drawing.Size(75, 23);
            this.btnAgregarMiembro.TabIndex = 1;
            this.btnAgregarMiembro.Text = "Agregar";
            this.btnAgregarMiembro.UseVisualStyleBackColor = true;
            this.btnAgregarMiembro.Click += new System.EventHandler(this.btnAgregarMiembro_Click);
             
            // btnEditarMiembro
             
            this.btnEditarMiembro.Location = new System.Drawing.Point(104, 380);
            this.btnEditarMiembro.Name = "btnEditarMiembro";
            this.btnEditarMiembro.Size = new System.Drawing.Size(75, 23);
            this.btnEditarMiembro.TabIndex = 2;
            this.btnEditarMiembro.Text = "Editar";
            this.btnEditarMiembro.UseVisualStyleBackColor = true;
            this.btnEditarMiembro.Click += new System.EventHandler(this.btnEditarMiembro_Click);
             
            // btnEliminarMiembro
             
            this.btnEliminarMiembro.Location = new System.Drawing.Point(196, 380);
            this.btnEliminarMiembro.Name = "btnEliminarMiembro";
            this.btnEliminarMiembro.Size = new System.Drawing.Size(75, 23);
            this.btnEliminarMiembro.TabIndex = 3;
            this.btnEliminarMiembro.Text = "Eliminar";
            this.btnEliminarMiembro.UseVisualStyleBackColor = true;
            this.btnEliminarMiembro.Click += new System.EventHandler(this.btnEliminarMiembro_Click);
             
            // MiembrosForm
             
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(784, 421);
            this.Controls.Add(this.btnEliminarMiembro);
            this.Controls.Add(this.btnEditarMiembro);
            this.Controls.Add(this.btnAgregarMiembro);
            this.Controls.Add(this.tablaMiembros);
            this.Name = "MiembrosForm";
            this.Text = "Miembros";
            ((System.ComponentModel.ISupportInitialize)(this.tablaMiembros)).EndInit();
            this.ResumeLayout(false);
        }
    }
}