﻿// Gestor10mos.Entities/Miembro.cs
namespace Gestor10mos.Entities
{
    public class Miembro
    {
        public string Nombre { get; set; }
        public string Apellido { get; set; }
        public string Correo { get; set; }
        public string Telefono { get; set; }

        public override string ToString() => $"{Nombre} {Apellido}";
    }
}