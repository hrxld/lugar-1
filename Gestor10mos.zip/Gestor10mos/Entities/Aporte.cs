﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Gestor10mos.Entities
{
    public class Aporte
    {
        public DateTime Fecha { get; set; }
        public decimal Monto { get; set; }
        public string Descripcion { get; set; }
        public string Miembro { get; set; }  // Para vincular con Nombre o Id de Miembro
    }
}
