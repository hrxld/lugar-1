﻿using System;
using System.Windows.Forms;
using System.Data;
using System.Data.SqlClient;

namespace Gestor10mos
{
    public partial class CuentasForm : Form
    {
        public CuentasForm()
        {
            InitializeComponent();
        }
    }
}
