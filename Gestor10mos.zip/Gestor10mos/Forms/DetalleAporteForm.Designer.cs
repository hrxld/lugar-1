﻿namespace Gestor10mos.Forms
{
    partial class DetalleAporteForm
    {
        private System.ComponentModel.IContainer components = null;
        private System.Windows.Forms.Label lblFecha;
        private System.Windows.Forms.DateTimePicker dtpFechaAporte;
        private System.Windows.Forms.Label lblMonto;
        private System.Windows.Forms.TextBox txtMontoAporte;
        private System.Windows.Forms.Label lblDescripcion;
        private System.Windows.Forms.TextBox txtDescripcionAporte;
        private System.Windows.Forms.Label lblMiembro;
        private System.Windows.Forms.ComboBox cmbMiembroAporte;
        private System.Windows.Forms.Button btnAceptar;
        private System.Windows.Forms.Button btnCancelar;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
                components.Dispose();
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.lblFecha = new System.Windows.Forms.Label();
            this.dtpFechaAporte = new System.Windows.Forms.DateTimePicker();
            this.lblMonto = new System.Windows.Forms.Label();
            this.txtMontoAporte = new System.Windows.Forms.TextBox();
            this.lblDescripcion = new System.Windows.Forms.Label();
            this.txtDescripcionAporte = new System.Windows.Forms.TextBox();
            this.lblMiembro = new System.Windows.Forms.Label();
            this.cmbMiembroAporte = new System.Windows.Forms.ComboBox();
            this.btnAceptar = new System.Windows.Forms.Button();
            this.btnCancelar = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblFecha
            // 
            this.lblFecha.AutoSize = true;
            this.lblFecha.Location = new System.Drawing.Point(20, 20);
            this.lblFecha.Name = "lblFecha";
            this.lblFecha.Size = new System.Drawing.Size(48, 16);
            this.lblFecha.TabIndex = 9;
            this.lblFecha.Text = "Fecha:";
            // 
            // dtpFechaAporte
            // 
            this.dtpFechaAporte.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpFechaAporte.Location = new System.Drawing.Point(100, 16);
            this.dtpFechaAporte.Name = "dtpFechaAporte";
            this.dtpFechaAporte.Size = new System.Drawing.Size(120, 22);
            this.dtpFechaAporte.TabIndex = 8;
            // 
            // lblMonto
            // 
            this.lblMonto.AutoSize = true;
            this.lblMonto.Location = new System.Drawing.Point(20, 60);
            this.lblMonto.Name = "lblMonto";
            this.lblMonto.Size = new System.Drawing.Size(47, 16);
            this.lblMonto.TabIndex = 7;
            this.lblMonto.Text = "Monto:";
            // 
            // txtMontoAporte
            // 
            this.txtMontoAporte.Location = new System.Drawing.Point(100, 56);
            this.txtMontoAporte.Name = "txtMontoAporte";
            this.txtMontoAporte.Size = new System.Drawing.Size(120, 22);
            this.txtMontoAporte.TabIndex = 6;
            // 
            // lblDescripcion
            // 
            this.lblDescripcion.AutoSize = true;
            this.lblDescripcion.Location = new System.Drawing.Point(20, 100);
            this.lblDescripcion.Name = "lblDescripcion";
            this.lblDescripcion.Size = new System.Drawing.Size(82, 16);
            this.lblDescripcion.TabIndex = 5;
            this.lblDescripcion.Text = "Descripción:";
            // 
            // txtDescripcionAporte
            // 
            this.txtDescripcionAporte.Location = new System.Drawing.Point(100, 96);
            this.txtDescripcionAporte.Multiline = true;
            this.txtDescripcionAporte.Name = "txtDescripcionAporte";
            this.txtDescripcionAporte.Size = new System.Drawing.Size(200, 60);
            this.txtDescripcionAporte.TabIndex = 4;
            // 
            // lblMiembro
            // 
            this.lblMiembro.AutoSize = true;
            this.lblMiembro.Location = new System.Drawing.Point(20, 170);
            this.lblMiembro.Name = "lblMiembro";
            this.lblMiembro.Size = new System.Drawing.Size(63, 16);
            this.lblMiembro.TabIndex = 3;
            this.lblMiembro.Text = "Miembro:";
            // 
            // cmbMiembroAporte
            // 
            this.cmbMiembroAporte.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbMiembroAporte.Location = new System.Drawing.Point(100, 166);
            this.cmbMiembroAporte.Name = "cmbMiembroAporte";
            this.cmbMiembroAporte.Size = new System.Drawing.Size(200, 24);
            this.cmbMiembroAporte.TabIndex = 2;
            // 
            // btnAceptar
            // 
            this.btnAceptar.DialogResult = System.Windows.Forms.DialogResult.OK;
            this.btnAceptar.Location = new System.Drawing.Point(80, 210);
            this.btnAceptar.Name = "btnAceptar";
            this.btnAceptar.Size = new System.Drawing.Size(75, 23);
            this.btnAceptar.TabIndex = 1;
            this.btnAceptar.Text = "Aceptar";
            this.btnAceptar.UseVisualStyleBackColor = true;
            // 
            // btnCancelar
            // 
            this.btnCancelar.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnCancelar.Location = new System.Drawing.Point(200, 210);
            this.btnCancelar.Name = "btnCancelar";
            this.btnCancelar.Size = new System.Drawing.Size(75, 23);
            this.btnCancelar.TabIndex = 0;
            this.btnCancelar.Text = "Cancelar";
            this.btnCancelar.UseVisualStyleBackColor = true;
            // 
            // DetalleAporteForm
            // 
            this.ClientSize = new System.Drawing.Size(350, 260);
            this.Controls.Add(this.btnCancelar);
            this.Controls.Add(this.btnAceptar);
            this.Controls.Add(this.cmbMiembroAporte);
            this.Controls.Add(this.lblMiembro);
            this.Controls.Add(this.txtDescripcionAporte);
            this.Controls.Add(this.lblDescripcion);
            this.Controls.Add(this.txtMontoAporte);
            this.Controls.Add(this.lblMonto);
            this.Controls.Add(this.dtpFechaAporte);
            this.Controls.Add(this.lblFecha);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.Name = "DetalleAporteForm";
            this.Text = "Detalle de Aporte";
            this.ResumeLayout(false);
            this.PerformLayout();

        }
    }
}