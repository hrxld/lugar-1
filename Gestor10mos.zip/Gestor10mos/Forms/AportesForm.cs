﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;
using Gestor10mos.Entities;
using System.Data;
using System.Data.SqlClient;

namespace Gestor10mos.Forms
{
    public partial class AportesForm : Form
    {
        private List<Aporte> aportes = new List<Aporte>();
        private List<string> miembros;

        public AportesForm(List<string> miembros)
        {
            InitializeComponent();
            this.miembros = miembros;
            CargarGrilla();
        }

        private void CargarGrilla()
        {
            dgvAportes.DataSource = null;
            dgvAportes.DataSource = aportes;
        }

        private void btnAgregarAporte_Click(object sender, EventArgs e)
        {
            using (var detalle = new DetalleAporteForm())
            {
                detalle.CargarMiembros(miembros);
                if (detalle.ShowDialog() == DialogResult.OK)
                {
                    aportes.Add(new Aporte
                    {
                        Fecha = detalle.FechaAporte,
                        Monto = detalle.MontoAporte,
                        Descripcion = detalle.DescripcionAporte,
                        Miembro = detalle.MiembroAporte
                    });
                    CargarGrilla();
                }
            }
        }

        private void btnEliminarAporte_Click(object sender, EventArgs e)
        {
            if (dgvAportes.SelectedRows.Count == 0) return;
            var idx = dgvAportes.SelectedRows[0].Index;
            if (MessageBox.Show("Eliminar aporte?", "Confirmar",
                                MessageBoxButtons.YesNo,
                                MessageBoxIcon.Question)
                == DialogResult.Yes)
            {
                aportes.RemoveAt(idx);
                CargarGrilla();
            }
        }
    }
}