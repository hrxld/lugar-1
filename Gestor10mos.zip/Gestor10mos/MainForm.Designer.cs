﻿using System.Windows.Forms;

namespace Gestor10mos.Forms
{
    partial class MainForm
    {
        private System.ComponentModel.IContainer components = null;
        private MenuStrip menuStrip;
        private ToolStripMenuItem mnuMiembros;
        private ToolStripMenuItem mnuAportes;
        private ToolStripMenuItem mnuCuentas;
        private ToolStripMenuItem mnuReportes;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.menuStrip = new System.Windows.Forms.MenuStrip();
            this.mnuMiembros = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuAportes = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuCuentas = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuReportes = new System.Windows.Forms.ToolStripMenuItem();

            // 
            // menuStrip
            // 
            this.menuStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
                this.mnuMiembros,
                this.mnuAportes,
                this.mnuCuentas,
                this.mnuReportes
            });
            this.menuStrip.Location = new System.Drawing.Point(0, 0);
            this.menuStrip.Name = "menuStrip";
            this.menuStrip.Size = new System.Drawing.Size(800, 24);

            // 
            // mnuMiembros
            // 
            this.mnuMiembros.Name = "mnuMiembros";
            this.mnuMiembros.Size = new System.Drawing.Size(67, 20);
            this.mnuMiembros.Text = "Miembros";
            this.mnuMiembros.Click += new System.EventHandler(this.mnuMiembros_Click);

            // 
            // mnuAportes
            // 
            this.mnuAportes.Name = "mnuAportes";
            this.mnuAportes.Size = new System.Drawing.Size(58, 20);
            this.mnuAportes.Text = "Aportes";
            this.mnuAportes.Click += new System.EventHandler(this.mnuAportes_Click);

            // 
            // mnuCuentas
            // 
            this.mnuCuentas.Name = "mnuCuentas";
            this.mnuCuentas.Size = new System.Drawing.Size(63, 20);
            this.mnuCuentas.Text = "Cuentas";
            this.mnuCuentas.Click += new System.EventHandler(this.mnuCuentas_Click);

            // 
            // mnuReportes
            // 
            this.mnuReportes.Name = "mnuReportes";
            this.mnuReportes.Size = new System.Drawing.Size(65, 20);
            this.mnuReportes.Text = "Reportes";
            this.mnuReportes.Click += new System.EventHandler(this.mnuReportes_Click);

            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.menuStrip);
            this.MainMenuStrip = this.menuStrip;
            this.Name = "MainForm";
            this.Text = "Gestor10mos";
            this.Load += new System.EventHandler(this.MainForm_Load);
        }
    }
}