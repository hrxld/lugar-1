﻿using System;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Windows.Forms;

namespace Gestor10mos
{
    public partial class CuentasForm : Form
    {
        private class CuentaBancaria
        {
            public string NumeroCuenta { get; set; }
            public string Banco { get; set; }
            public string Responsable { get; set; }
        }

        private BindingList<CuentaBancaria> _lista;
        private const string ArchivoCsv = "cuentas.csv";

        public CuentasForm()
        {
            InitializeComponent();

            btnGuardar.Click += BtnGuardar_Click;
            btnRefrescar.Click += (s, e) => CargarCuentas();
            CargarCuentas();
        }

        private void CargarCuentas()
        {
            if (File.Exists(ArchivoCsv))
            {
                var datos = File.ReadAllLines(ArchivoCsv)
                               .Select(l => l.Split(';'))
                               .Where(p => p.Length == 3)
                               .Select(p => new CuentaBancaria
                               {
                                   NumeroCuenta = p[0],
                                   Banco = p[1],
                                   Responsable = p[2]
                               })
                               .ToList();
                _lista = new BindingList<CuentaBancaria>(datos);
            }
            else
            {
                _lista = new BindingList<CuentaBancaria>();
            }

            dgvCuentas.DataSource = _lista;
        }

        private void GuardarCuentas()
        {
            var lineas = _lista
                .Select(c => $"{c.NumeroCuenta};{c.Banco};{c.Responsable}");
            File.WriteAllLines(ArchivoCsv, lineas);
        }

        private void BtnGuardar_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtNumero.Text) ||
                string.IsNullOrWhiteSpace(txtBanco.Text) ||
                string.IsNullOrWhiteSpace(txtResponsable.Text))
            {
                MessageBox.Show(
                    "Completa todos los campos",
                    "Atención",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Warning);
                return;
            }

            _lista.Add(new CuentaBancaria
            {
                NumeroCuenta = txtNumero.Text.Trim(),
                Banco = txtBanco.Text.Trim(),
                Responsable = txtResponsable.Text.Trim()
            });

            GuardarCuentas();
            MessageBox.Show(
                "Cuenta guardada",
                "Éxito",
                MessageBoxButtons.OK,
                MessageBoxIcon.Information);
            CargarCuentas();
        }

        private void BtnEliminar_Click(object sender, EventArgs e)
        {
            if (dgvCuentas.SelectedRows.Count == 0)
            {
                MessageBox.Show(
                    "Selecciona primero la fila que quieres eliminar.",
                    "Aviso",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Warning);
                return;
            }

            var cuenta = dgvCuentas.SelectedRows[0].DataBoundItem
                          as CuentaBancaria;
            if (cuenta == null) return;

            var resp = MessageBox.Show(
                $"¿Eliminar la cuenta {cuenta.NumeroCuenta} de {cuenta.Banco}?",
                "Confirmar eliminación",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Question);

            if (resp == DialogResult.Yes)
            {
                _lista.Remove(cuenta);
                GuardarCuentas();
                CargarCuentas();
            }
        }
    }
}