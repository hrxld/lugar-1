﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Windows.Forms;
using Gestor10mos.Entities;

namespace Gestor10mos.Forms
{
    public partial class ReportesForm : Form
    {
        private List<Aporte> todosLosAportes;
        private const string ArchivoCsv = "aportes.csv";

        public ReportesForm()
        {
            InitializeComponent();
            CargarAportes();
            ConfigurarDatePickers();
            MostrarEnGrilla(todosLosAportes);
        }

        private void CargarAportes()
        {
            if (!File.Exists(ArchivoCsv))
            {
                todosLosAportes = new List<Aporte>();
                return;
            }

            todosLosAportes = File.ReadAllLines(ArchivoCsv)
                .Select(line => line.Split(';'))
                .Where(p => p.Length == 4
                         && DateTime.TryParse(p[0], out _)
                         && decimal.TryParse(p[1],
                              NumberStyles.Any,
                              CultureInfo.InvariantCulture,
                              out _))
                .Select(p => new Aporte
                {
                    Fecha = DateTime.Parse(p[0], CultureInfo.InvariantCulture),
                    Monto = decimal.Parse(p[1], CultureInfo.InvariantCulture),
                    Descripcion = p[2],
                    Miembro = p[3]
                })
                .ToList();
        }

        private void ConfigurarDatePickers()
        {
            if (todosLosAportes.Any())
            {
                DateTime min = todosLosAportes.Min(a => a.Fecha);
                DateTime max = todosLosAportes.Max(a => a.Fecha);
                dtpDesde.Value = min;
                dtpHasta.Value = max;
            }
        }

        private void MostrarEnGrilla(IEnumerable<Aporte> lista)
        {
            dgvReportes.DataSource = null;
            dgvReportes.DataSource = lista.ToList();
        }

        private void btnFiltrar_Click(object sender, EventArgs e)
        {
            DateTime desde = dtpDesde.Value.Date;
            DateTime hasta = dtpHasta.Value.Date;

            if (desde > hasta)
            {
                MessageBox.Show("La fecha 'Desde' no puede ser mayor que 'Hasta'.",
                                "Rango inválido",
                                MessageBoxButtons.OK,
                                MessageBoxIcon.Warning);
                return;
            }

            var filtrados = todosLosAportes
                .Where(a => a.Fecha.Date >= desde && a.Fecha.Date <= hasta)
                .ToList();

            MostrarEnGrilla(filtrados);
        }

        private void btnEliminarReporte_Click(object sender, EventArgs e)
        {
            if (dgvReportes.SelectedRows.Count == 0) return;

            var aporte = (Aporte)dgvReportes.SelectedRows[0].DataBoundItem;

            if (MessageBox.Show("¿Eliminar aporte seleccionado?",
                                "Confirmar eliminación",
                                MessageBoxButtons.YesNo,
                                MessageBoxIcon.Question)
                != DialogResult.Yes)
                return;

            todosLosAportes.Remove(aporte);

            File.WriteAllLines(
                ArchivoCsv,
                todosLosAportes.Select(a =>
                    $"{a.Fecha:yyyy-MM-dd};" +
                    $"{a.Monto.ToString(CultureInfo.InvariantCulture)};" +
                    $"{a.Descripcion};{a.Miembro}"
                )
            );

            MostrarEnGrilla(todosLosAportes);
        }
    }
}