﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;
using Gestor10mos.Entities;
using System.Data;
using System.Data.SqlClient;

namespace Gestor10mos
{
    public partial class MiembrosForm : Form
    {
        private List<Miembro> miembros;
        private int editingIndex = -1;
        private bool isEditing = false;

        public MiembrosForm(List<Miembro> miembros)
        {
            InitializeComponent();
            this.miembros = miembros ?? new List<Miembro>();
            CargarGrid();

            dgvMiembros.DataBindingComplete += dgvMiembros_DataBindingComplete;
            dgvMiembros.CellClick += dgvMiembros_CellClick;
        }

        private void CargarGrid()
        {
            dgvMiembros.DataSource = null;
            dgvMiembros.DataSource = miembros;
        }

        private void dgvMiembros_DataBindingComplete(object sender, DataGridViewBindingCompleteEventArgs e)
        {
            dgvMiembros.ClearSelection();
            editingIndex = -1;
            isEditing = false;
            btnAgregarMiembro.Text = "Agregar Miembro";
            txtNombre.Clear();
            txtApellido.Clear();
            txtCorreo.Clear();
            txtTelefono.Clear();
        }

        private void dgvMiembros_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex < 0) return;
            editingIndex = e.RowIndex;
        }

        private void btnEditarMiembro_Click(object sender, EventArgs e)
        {
            if (editingIndex < 0)
            {
                MessageBox.Show("Selecciona un miembro para editar.", "Aviso",
                                MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            var sel = miembros[editingIndex];
            txtNombre.Text = sel.Nombre;
            txtApellido.Text = sel.Apellido;
            txtCorreo.Text = sel.Correo;
            txtTelefono.Text = sel.Telefono;
            isEditing = true;
            btnAgregarMiembro.Text = "Guardar Cambios";
        }

        private void btnAgregarMiembro_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtNombre.Text) ||
                string.IsNullOrWhiteSpace(txtApellido.Text) ||
                string.IsNullOrWhiteSpace(txtCorreo.Text) ||
                string.IsNullOrWhiteSpace(txtTelefono.Text))
            {
                MessageBox.Show("Completa todos los campos.", "Aviso",
                                MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (isEditing)
            {
                var m = miembros[editingIndex];
                m.Nombre = txtNombre.Text.Trim();
                m.Apellido = txtApellido.Text.Trim();
                m.Correo = txtCorreo.Text.Trim();
                m.Telefono = txtTelefono.Text.Trim();
                isEditing = false;
                editingIndex = -1;
                btnAgregarMiembro.Text = "Agregar Miembro";
            }
            else
            {
                miembros.Add(new Miembro
                {
                    Nombre = txtNombre.Text.Trim(),
                    Apellido = txtApellido.Text.Trim(),
                    Correo = txtCorreo.Text.Trim(),
                    Telefono = txtTelefono.Text.Trim()
                });
            }

            CargarGrid();
        }

        private void btnEliminarMiembro_Click(object sender, EventArgs e)
        {
            if (editingIndex < 0)
            {
                MessageBox.Show("Selecciona un miembro para eliminar.", "Aviso",
                                MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            var m = miembros[editingIndex];
            var resp = MessageBox.Show($"¿Eliminar a {m.Nombre} {m.Apellido}?",
                                       "Confirmar",
                                       MessageBoxButtons.YesNo,
                                       MessageBoxIcon.Question);
            if (resp == DialogResult.Yes)
            {
                miembros.RemoveAt(editingIndex);
                CargarGrid();
            }
        }
    }
}