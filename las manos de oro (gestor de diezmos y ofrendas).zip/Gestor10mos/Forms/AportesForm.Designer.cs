﻿namespace Gestor10mos.Forms
{
    partial class AportesForm
    {
        private System.ComponentModel.IContainer components = null;
        private System.Windows.Forms.DataGridView dgvAportes;
        private System.Windows.Forms.Button btnAgregarAporte;
        private System.Windows.Forms.Button btnEliminarAporte;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
                components.Dispose();
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.dgvAportes = new System.Windows.Forms.DataGridView();
            this.btnAgregarAporte = new System.Windows.Forms.Button();
            this.btnEliminarAporte = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dgvAportes)).BeginInit();
            this.SuspendLayout();
            
            // dgvAportes
             
            this.dgvAportes.AllowUserToAddRows = false;
            this.dgvAportes.ReadOnly = true;
            this.dgvAportes.MultiSelect = false;
            this.dgvAportes.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvAportes.RowHeadersVisible = false;
            this.dgvAportes.Location = new System.Drawing.Point(12, 12);
            this.dgvAportes.Size = new System.Drawing.Size(460, 250);
            
            // btnAgregarAporte
           
            this.btnAgregarAporte.Location = new System.Drawing.Point(12, 275);
            this.btnAgregarAporte.Size = new System.Drawing.Size(120, 30);
            this.btnAgregarAporte.Text = "Agregar Aporte";
            this.btnAgregarAporte.UseVisualStyleBackColor = true;
            this.btnAgregarAporte.Click += new System.EventHandler(this.btnAgregarAporte_Click);
            
            // btnEliminarAporte
             
            this.btnEliminarAporte.Location = new System.Drawing.Point(150, 275);
            this.btnEliminarAporte.Size = new System.Drawing.Size(120, 30);
            this.btnEliminarAporte.Text = "Eliminar Aporte";
            this.btnEliminarAporte.UseVisualStyleBackColor = true;
            this.btnEliminarAporte.Click += new System.EventHandler(this.btnEliminarAporte_Click);
             
            // AportesForm
            
            this.ClientSize = new System.Drawing.Size(484, 321);
            this.Controls.Add(this.btnEliminarAporte);
            this.Controls.Add(this.btnAgregarAporte);
            this.Controls.Add(this.dgvAportes);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.Name = "AportesForm";
            this.Text = "Gestión de Aportes";
            ((System.ComponentModel.ISupportInitialize)(this.dgvAportes)).EndInit();
            this.ResumeLayout(false);
        }
    }
}