﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Windows.Forms;
using Gestor10mos.Entities;

namespace Gestor10mos.Forms
{
    public partial class AportesForm : Form
    {
        private List<Aporte> aportes = new List<Aporte>();
        private List<string> miembros;
        private const string ArchivoCsv = "aportes.csv";

        public AportesForm(List<string> miembros)
        {
            InitializeComponent();
            this.miembros = miembros;
            CargarAportesDesdeCsv();
            CargarGrilla();
        }

        private void CargarAportesDesdeCsv()
        {
            if (!File.Exists(ArchivoCsv))
            {
                aportes = new List<Aporte>();
                return;
            }

            aportes = File.ReadAllLines(ArchivoCsv)
                          .Select(line => line.Split(';'))
                          .Where(p => p.Length == 4
                                   && DateTime.TryParse(p[0], out _)
                                   && decimal.TryParse(p[1],
                                        NumberStyles.Any,
                                        CultureInfo.InvariantCulture,
                                        out _))
                          .Select(p => new Aporte
                          {
                              Fecha = DateTime.Parse(p[0], CultureInfo.InvariantCulture),
                              Monto = decimal.Parse(p[1], CultureInfo.InvariantCulture),
                              Descripcion = p[2],
                              Miembro = p[3]
                          })
                          .ToList();
        }

        private void GuardarAportes()
        {
            var lines = aportes.Select(a =>
                $"{a.Fecha:yyyy-MM-dd};" +
                $"{a.Monto.ToString(CultureInfo.InvariantCulture)};" +
                $"{a.Descripcion};" +
                $"{a.Miembro}");

            File.WriteAllLines(ArchivoCsv, lines);
        }

        private void CargarGrilla()
        {
            dgvAportes.DataSource = null;
            dgvAportes.DataSource = aportes;
        }

        private void btnAgregarAporte_Click(object sender, EventArgs e)
        {
            using (var detalle = new DetalleAporteForm())
            {
                detalle.CargarMiembros(miembros);
                if (detalle.ShowDialog() != DialogResult.OK)
                    return;

                var nuevo = new Aporte
                {
                    Fecha = detalle.FechaAporte,
                    Monto = detalle.MontoAporte,
                    Descripcion = detalle.DescripcionAporte,
                    Miembro = detalle.MiembroAporte
                };

                aportes.Add(nuevo);
                GuardarAportes();
                CargarGrilla();
            }
        }

        private void btnEliminarAporte_Click(object sender, EventArgs e)
        {
            if (dgvAportes.SelectedRows.Count == 0) return;

            var idx = dgvAportes.SelectedRows[0].Index;
            if (MessageBox.Show("Eliminar aporte?", "Confirmar",
                                MessageBoxButtons.YesNo,
                                MessageBoxIcon.Question)
                != DialogResult.Yes)
                return;

            aportes.RemoveAt(idx);
            GuardarAportes();
            CargarGrilla();
        }
    }
}