﻿using System;
using System.Windows.Forms;
using System.Data;
using System.Data.SqlClient;

namespace Gestor10mos.Forms
{
    public partial class DetalleMiembroForm : Form
    {
        public DetalleMiembroForm()
        {
            InitializeComponent();
        }

        public string NombreMiembro
        {
            get => txtNombreMiembro.Text;
            set => txtNombreMiembro.Text = value;
        }

        public string ApellidoMiembro
        {
            get => txtApellidoMiembro.Text;
            set => txtApellidoMiembro.Text = value;
        }

        public DateTime FechaIngresoMiembro
        {
            get => dtpFechaIngresoMiembro.Value;
            set => dtpFechaIngresoMiembro.Value = value;
        }

        public string TelefonoMiembro
        {
            get => txtTelefonoMiembro.Text;
            set => txtTelefonoMiembro.Text = value;
        }

        public string EmailMiembro
        {
            get => txtEmailMiembro.Text;
            set => txtEmailMiembro.Text = value;
        }
    }
}