﻿namespace Gestor10mos.Forms
{
    partial class DetalleMiembroForm
    {
        private System.ComponentModel.IContainer components = null;
        private System.Windows.Forms.Label lblNombre;
        private System.Windows.Forms.TextBox txtNombreMiembro;
        private System.Windows.Forms.Label lblApellido;
        private System.Windows.Forms.TextBox txtApellidoMiembro;
        private System.Windows.Forms.Label lblFechaIngreso;
        private System.Windows.Forms.DateTimePicker dtpFechaIngresoMiembro;
        private System.Windows.Forms.Label lblTelefono;
        private System.Windows.Forms.TextBox txtTelefonoMiembro;
        private System.Windows.Forms.Label lblEmail;
        private System.Windows.Forms.TextBox txtEmailMiembro;
        private System.Windows.Forms.Button btnAceptar;
        private System.Windows.Forms.Button btnCancelar;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
                components.Dispose();
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.lblNombre = new System.Windows.Forms.Label();
            this.txtNombreMiembro = new System.Windows.Forms.TextBox();
            this.lblApellido = new System.Windows.Forms.Label();
            this.txtApellidoMiembro = new System.Windows.Forms.TextBox();
            this.lblFechaIngreso = new System.Windows.Forms.Label();
            this.dtpFechaIngresoMiembro = new System.Windows.Forms.DateTimePicker();
            this.lblTelefono = new System.Windows.Forms.Label();
            this.txtTelefonoMiembro = new System.Windows.Forms.TextBox();
            this.lblEmail = new System.Windows.Forms.Label();
            this.txtEmailMiembro = new System.Windows.Forms.TextBox();
            this.btnAceptar = new System.Windows.Forms.Button();
            this.btnCancelar = new System.Windows.Forms.Button();
            this.SuspendLayout();
             
            // lblNombre
            
            this.lblNombre.AutoSize = true;
            this.lblNombre.Location = new System.Drawing.Point(20, 20);
            this.lblNombre.Name = "lblNombre";
            this.lblNombre.Text = "Nombre:";
            
            // txtNombreMiembro
             
            this.txtNombreMiembro.Location = new System.Drawing.Point(120, 17);
            this.txtNombreMiembro.Name = "txtNombreMiembro";
            this.txtNombreMiembro.Size = new System.Drawing.Size(200, 20);
            
            // lblApellido
            
            this.lblApellido.AutoSize = true;
            this.lblApellido.Location = new System.Drawing.Point(20, 60);
            this.lblApellido.Name = "lblApellido";
            this.lblApellido.Text = "Apellido:";
            
            // txtApellidoMiembro
            
            this.txtApellidoMiembro.Location = new System.Drawing.Point(120, 57);
            this.txtApellidoMiembro.Name = "txtApellidoMiembro";
            this.txtApellidoMiembro.Size = new System.Drawing.Size(200, 20);
            
            // lblFechaIngreso
             
            this.lblFechaIngreso.AutoSize = true;
            this.lblFechaIngreso.Location = new System.Drawing.Point(20, 100);
            this.lblFechaIngreso.Name = "lblFechaIngreso";
            this.lblFechaIngreso.Text = "Fecha Ingreso:";
             
            // dtpFechaIngresoMiembro
             
            this.dtpFechaIngresoMiembro.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpFechaIngresoMiembro.Location = new System.Drawing.Point(120, 97);
            this.dtpFechaIngresoMiembro.Name = "dtpFechaIngresoMiembro";
            this.dtpFechaIngresoMiembro.Size = new System.Drawing.Size(200, 20);
             
            // lblTelefono
             
            this.lblTelefono.AutoSize = true;
            this.lblTelefono.Location = new System.Drawing.Point(20, 140);
            this.lblTelefono.Name = "lblTelefono";
            this.lblTelefono.Text = "Teléfono:";
             
            // txtTelefonoMiembro
            
            this.txtTelefonoMiembro.Location = new System.Drawing.Point(120, 137);
            this.txtTelefonoMiembro.Name = "txtTelefonoMiembro";
            this.txtTelefonoMiembro.Size = new System.Drawing.Size(200, 20);
             
            // lblEmail
             
            this.lblEmail.AutoSize = true;
            this.lblEmail.Location = new System.Drawing.Point(20, 180);
            this.lblEmail.Name = "lblEmail";
            this.lblEmail.Text = "Email:";
             
            // txtEmailMiembro
             
            this.txtEmailMiembro.Location = new System.Drawing.Point(120, 177);
            this.txtEmailMiembro.Name = "txtEmailMiembro";
            this.txtEmailMiembro.Size = new System.Drawing.Size(200, 20);
             
            // btnAceptar
             
            this.btnAceptar.DialogResult = System.Windows.Forms.DialogResult.OK;
            this.btnAceptar.Location = new System.Drawing.Point(80, 220);
            this.btnAceptar.Name = "btnAceptar";
            this.btnAceptar.Size = new System.Drawing.Size(75, 23);
            this.btnAceptar.Text = "Aceptar";
            this.btnAceptar.UseVisualStyleBackColor = true;
             
            // btnCancelar
             
            this.btnCancelar.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnCancelar.Location = new System.Drawing.Point(200, 220);
            this.btnCancelar.Name = "btnCancelar";
            this.btnCancelar.Size = new System.Drawing.Size(75, 23);
            this.btnCancelar.Text = "Cancelar";
            this.btnCancelar.UseVisualStyleBackColor = true;
             
            // DetalleMiembroForm
             
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(350, 270);
            this.Controls.Add(this.btnCancelar);
            this.Controls.Add(this.btnAceptar);
            this.Controls.Add(this.txtEmailMiembro);
            this.Controls.Add(this.lblEmail);
            this.Controls.Add(this.txtTelefonoMiembro);
            this.Controls.Add(this.lblTelefono);
            this.Controls.Add(this.dtpFechaIngresoMiembro);
            this.Controls.Add(this.lblFechaIngreso);
            this.Controls.Add(this.txtApellidoMiembro);
            this.Controls.Add(this.lblApellido);
            this.Controls.Add(this.txtNombreMiembro);
            this.Controls.Add(this.lblNombre);
            this.Name = "DetalleMiembroForm";
            this.Text = "Detalle de Miembro";
            this.ResumeLayout(false);
            this.PerformLayout();
        }
    }
}