﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;
using Gestor10mos.Entities;

namespace Gestor10mos.Forms
{
    public partial class MainForm : Form
    {
        private List<Miembro> miembros = new List<Miembro>();

        public MainForm()
        {
            InitializeComponent();
        }

        // 🔧 Este método es llamado al cargar el formulario
        private void MainForm_Load(object sender, EventArgs e)
        {
            // Puedes dejarlo vacío
        }

        // 🔧 Este método es llamado al hacer clic en "Miembros"
        private void mnuMiembros_Click(object sender, EventArgs e)
        {
            using (var frm = new MiembrosForm())
                frm.ShowDialog();
        }

        // 🔧 Este método es llamado al hacer clic en "Aportes"
        private void mnuAportes_Click(object sender, EventArgs e)
        {
            var nombres = miembros
                .Select(m => m.Nombre + " " + m.Apellido)
                .ToList();

            using (var frm = new AportesForm(nombres))
                frm.ShowDialog();
        }

        // 🔧 Este método es llamado al hacer clic en "Cuentas"
        private void mnuCuentas_Click(object sender, EventArgs e)
        {
            using (var frm = new CuentasForm())
                frm.ShowDialog();
        }

        // 🔧 Este método es llamado al hacer clic en "Reportes"
        private void mnuReportes_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Aquí irán los reportes.", "Reportes");
        }
    }
}