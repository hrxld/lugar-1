﻿using System;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

namespace Gestor10mos
{
    partial class CuentasForm
    {
        private IContainer components = null;
        private DataGridView dgvCuentas;
        private Label lblNumero;
        private TextBox txtNumero;
        private Label lblBanco;
        private TextBox txtBanco;
        private Label lblResponsable;
        private TextBox txtResponsable;
        private Button btnGuardar;
        private Button btnRefrescar;
        private Button btnEliminar;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
                components.Dispose();
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.dgvCuentas = new DataGridView();
            this.lblNumero = new Label();
            this.txtNumero = new TextBox();
            this.lblBanco = new Label();
            this.txtBanco = new TextBox();
            this.lblResponsable = new Label();
            this.txtResponsable = new TextBox();
            this.btnGuardar = new Button();
            this.btnRefrescar = new Button();
            this.btnEliminar = new Button();

            ((ISupportInitialize)(this.dgvCuentas)).BeginInit();
            this.SuspendLayout();
            // 
            // dgvCuentas
            // 
            this.dgvCuentas.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvCuentas.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvCuentas.Dock = DockStyle.Top;
            this.dgvCuentas.Location = new Point(0, 0);
            this.dgvCuentas.Name = "dgvCuentas";
            this.dgvCuentas.Size = new Size(686, 213);
            this.dgvCuentas.TabIndex = 0;
            this.dgvCuentas.MultiSelect = false;
            this.dgvCuentas.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            // 
            // lblNumero
            // 
            this.lblNumero.AutoSize = true;
            this.lblNumero.Location = new Point(14, 229);
            this.lblNumero.Name = "lblNumero";
            this.lblNumero.Size = new Size(120, 16);
            this.lblNumero.TabIndex = 8;
            this.lblNumero.Text = "Número de cuenta:";
            // 
            // txtNumero
            // 
            this.txtNumero.Location = new Point(149, 226);
            this.txtNumero.Name = "txtNumero";
            this.txtNumero.Size = new Size(228, 22);
            this.txtNumero.TabIndex = 1;
            // 
            // lblBanco
            // 
            this.lblBanco.AutoSize = true;
            this.lblBanco.Location = new Point(14, 261);
            this.lblBanco.Name = "lblBanco";
            this.lblBanco.Size = new Size(49, 16);
            this.lblBanco.TabIndex = 7;
            this.lblBanco.Text = "Banco:";
            // 
            // txtBanco
            // 
            this.txtBanco.Location = new Point(149, 258);
            this.txtBanco.Name = "txtBanco";
            this.txtBanco.Size = new Size(228, 22);
            this.txtBanco.TabIndex = 2;
            // 
            // lblResponsable
            // 
            this.lblResponsable.AutoSize = true;
            this.lblResponsable.Location = new Point(14, 293);
            this.lblResponsable.Name = "lblResponsable";
            this.lblResponsable.Size = new Size(92, 16);
            this.lblResponsable.TabIndex = 6;
            this.lblResponsable.Text = "Responsable:";
            // 
            // txtResponsable
            // 
            this.txtResponsable.Location = new Point(149, 290);
            this.txtResponsable.Name = "txtResponsable";
            this.txtResponsable.Size = new Size(228, 22);
            this.txtResponsable.TabIndex = 3;
            // 
            // btnGuardar
            // 
            this.btnGuardar.Location = new Point(411, 226);
            this.btnGuardar.Name = "btnGuardar";
            this.btnGuardar.Size = new Size(103, 32);
            this.btnGuardar.TabIndex = 4;
            this.btnGuardar.Text = "Guardar";
            this.btnGuardar.UseVisualStyleBackColor = true;
            // 
            // btnRefrescar
            // 
            this.btnRefrescar.Location = new Point(411, 269);
            this.btnRefrescar.Name = "btnRefrescar";
            this.btnRefrescar.Size = new Size(103, 32);
            this.btnRefrescar.TabIndex = 5;
            this.btnRefrescar.Text = "Refrescar";
            this.btnRefrescar.UseVisualStyleBackColor = true;
            // 
            // btnEliminar
            // 
            this.btnEliminar.Location = new Point(547, 227);
            this.btnEliminar.Name = "btnEliminar";
            this.btnEliminar.Size = new Size(90, 30);
            this.btnEliminar.TabIndex = 9;
            this.btnEliminar.Text = "Eliminar";
            this.btnEliminar.UseVisualStyleBackColor = true;
            this.btnEliminar.Click += new EventHandler(this.BtnEliminar_Click);
            // 
            // CuentasForm
            // 
            this.AutoScaleDimensions = new SizeF(8F, 16F);
            this.AutoScaleMode = AutoScaleMode.Font;
            this.ClientSize = new Size(686, 341);
            this.Controls.Add(this.btnEliminar);
            this.Controls.Add(this.btnRefrescar);
            this.Controls.Add(this.btnGuardar);
            this.Controls.Add(this.txtResponsable);
            this.Controls.Add(this.lblResponsable);
            this.Controls.Add(this.txtBanco);
            this.Controls.Add(this.lblBanco);
            this.Controls.Add(this.txtNumero);
            this.Controls.Add(this.lblNumero);
            this.Controls.Add(this.dgvCuentas);
            this.Name = "CuentasForm";
            this.Text = "Cuentas Bancarias";
            ((ISupportInitialize)(this.dgvCuentas)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();
        }
    }
}